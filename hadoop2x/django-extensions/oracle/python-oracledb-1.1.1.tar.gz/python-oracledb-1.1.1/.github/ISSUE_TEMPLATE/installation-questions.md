---
name: Installation Problems
about: Use this for python-oracledb installation questions
title: ''
labels: install & configuration
assignees: ''

---

<!--

Please start a discussion at https://github.com/oracle/python-oracledb/discussions instead of creating an Issue.

Give as much background information as possible: versions, runnable code, all SQL to create tables etc.

But first Review:

    - the Installation Instructions: https://python-oracledb.readthedocs.io/en/latest/user_guide/installation.html

    - the troubleshooting tips: https://python-oracledb.readthedocs.io/en/latest/user_guide/installation.html#troubleshooting

-->
