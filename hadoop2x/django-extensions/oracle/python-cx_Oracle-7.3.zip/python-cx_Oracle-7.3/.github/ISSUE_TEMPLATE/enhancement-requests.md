---
name: Enhancement Requests
about: Use this for enhancement requests
title: ''
labels: enhancement
assignees: ''

---

1. Review existing [enhancement requests](https://github.com/oracle/python-cx_Oracle/labels/enhancement)

2. Describe your new request in detail

3. Give supporting information about tools and operating systems.  Give relevant product version numbers
