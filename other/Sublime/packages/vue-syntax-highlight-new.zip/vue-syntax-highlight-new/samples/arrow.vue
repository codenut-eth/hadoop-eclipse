<!--
This was a bug in the old implementation.
-->

<template>
  <div @click="foo => foo()"></div>
</template>
