<!-- See JSX section in README -->

<script>
export default {
  render () {
    return <div>{ this.foo }</div>
  }
}
</script>
