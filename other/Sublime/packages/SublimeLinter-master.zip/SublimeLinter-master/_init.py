from .lint.generic_text_command import sl_generic_text_cmd  # noqa: F401
