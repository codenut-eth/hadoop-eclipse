PROTECTED_REGIONS_KEY = "sublime_linter.protected_regions"
IS_ENABLED_SWITCH = "SublimeLinter.enabled?"

WARNING = "warning"
ERROR = "error"
