# only used for LSP-* packages out in the wild that now import from "private" modules
# TODO: Announce removal and remove this import
from .sessions import method2attr  # noqa
