## Designs

https://dribbble.com/shots/14527824-Food-Delivery-Mobile-App

https://www.byprogrammers.com/2020/11/how-to-integrate-google-maps-in-react-native-app/

## Run

1. Run `npm install`
2. Run `react-native run-android` to run this application in an Android emulator

## Demo

https://drive.google.com/file/d/1N3YUUrOUNQmWNgKoMC5KQYdHICmtsf0o/view?usp=sharing
