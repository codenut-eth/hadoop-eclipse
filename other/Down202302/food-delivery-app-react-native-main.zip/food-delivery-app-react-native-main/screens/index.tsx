import { HomeScreen } from './Home';
import { RestaurantScreen } from './Restaurant';
import { OrderDeliveryScreen } from './OrderDelivery';

export { HomeScreen, RestaurantScreen, OrderDeliveryScreen };