export { default as Comment } from './Comment';
