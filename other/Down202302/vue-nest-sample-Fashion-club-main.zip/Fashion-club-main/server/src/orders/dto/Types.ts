export enum Places {
  Home,
  Office,
}

export interface ProductSent {
  id: string;
  name: string;
}
