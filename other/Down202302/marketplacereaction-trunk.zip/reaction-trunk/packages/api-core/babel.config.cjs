module.exports = require("@reactioncommerce/api-utils/lib/configs/babel.config.cjs");
