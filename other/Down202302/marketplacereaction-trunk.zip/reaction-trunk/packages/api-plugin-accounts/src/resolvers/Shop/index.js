import groups from "./groups.js";

export default {
  groups
};
