export default {
  addressEdge: ({ address }) => address
};
