---
"@reactioncommerce/api-core": minor
"@reactioncommerce/api-plugin-accounts": minor
"@reactioncommerce/api-plugin-orders": minor
"@reactioncommerce/api-plugin-products": minor
"@reactioncommerce/api-utils": minor
---

Filter feature. This new feature provides a common function that can be used in a new query endpoint to get filtered results from any collection.
