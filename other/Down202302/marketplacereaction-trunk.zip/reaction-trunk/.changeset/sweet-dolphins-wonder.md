---
"@reactioncommerce/api-core": minor
"@reactioncommerce/file-collections-sa-gridfs": minor
---

feat: upgrade mongodb to 4.4
