/**
 *
 * @todo TEMP Mocks these will be removed in favor of a fixture/factory solution
 */

export const internalShopId = "123";
export const opaqueShopId = "cmVhY3Rpb24vc2hvcDoxMjM="; // reaction/shop:123
export const shopName = "Test Shop";
