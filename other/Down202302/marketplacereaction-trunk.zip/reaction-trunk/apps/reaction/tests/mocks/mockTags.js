/**
 *
 * @todo TEMP mocks these will be removed in favor of a fixture/factory solution
 */

export const internalTagIds = ["923", "924"];
export const opaqueTagIds = ["cmVhY3Rpb24vdGFnOjkyMw==", "cmVhY3Rpb24vdGFnOjkyNA=="]; // reaction/tag
