# Integration Tests

This folder contains test files that run GraphQL integration tests. Refer to [the documentation](https://docs.reactioncommerce.com/reaction-docs/trunk/running-jest-integration-tests).
