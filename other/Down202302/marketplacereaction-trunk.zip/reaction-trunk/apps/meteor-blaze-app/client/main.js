// eslint-disable-next-line node/no-unpublished-import, node/no-missing-import
import "/imports/client";
