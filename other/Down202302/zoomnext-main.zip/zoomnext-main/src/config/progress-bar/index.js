const progressBarConfig = () => ({
  barColors: {
    0: '#2563eb',
  },
  shadowBlur: 5,
});

export default progressBarConfig;
