module.exports = {
  images: {
    domains: [''],
  },
  reactStrictMode: true,
};
