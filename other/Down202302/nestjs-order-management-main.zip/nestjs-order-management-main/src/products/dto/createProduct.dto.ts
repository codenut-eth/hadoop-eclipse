export class CreateProductDto {
  productCode: string;
  productName: string;
  price: number;
}

export default CreateProductDto;
