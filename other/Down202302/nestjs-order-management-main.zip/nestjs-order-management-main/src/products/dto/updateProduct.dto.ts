export class UpdateProductDto {
  id: number;
  productCode: string;
  productName: string;
  price: number;
}

export default UpdateProductDto;
