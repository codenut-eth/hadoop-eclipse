export class GetDailyReportDto {
  startDate: Date;
  endDate: Date;
}

export default GetDailyReportDto;
