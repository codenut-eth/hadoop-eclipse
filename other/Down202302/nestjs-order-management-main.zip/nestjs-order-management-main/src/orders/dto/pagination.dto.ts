export class PaginationDto {
  page: number;
  limit: number;
}
