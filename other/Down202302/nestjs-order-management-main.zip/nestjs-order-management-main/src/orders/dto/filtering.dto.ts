export class FilteringDto {
  id?: number;
  orderCode?: string;
  orderType?: string;
  orderStatus?: string;
}
